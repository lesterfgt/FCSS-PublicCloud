This directory is used to store the license files for BYOL instances
